# Examples

## Disclaimer

These contracts are for demonstrative purposes only.
While these contracts have unit tests, and we generally expect them to be
correct, there are no guarantees about the correctness or security of 
these contracts. We hold these contracts to a different standard of 
correctness and security than other contracts in this repository. 
E.g., we have explicitly excluded these contracts from the
[bug bounty](https://uniswap.org/bug-bounty/#scope). 

You must do your own due diligence if you wish to use code
from these examples in your project.
